package Game;

public class Admin extends Player {

    /*
         public Admin(String name,
                        String firstAnswer,
                        TakeLetter guessBehavior,
                        EstimateQuestionBehaviors estimateBehavior) {

        super(name, new HangmanEngine(firstAnswer, guessBehavior, estimateBehavior));
    }*/
    // delete işlemleri flan bağlıcaz sana 
    public Admin() {
        super(null, 0, null);

    }

    @Override
    public String displayWhichPlayer() {

        return "Welcome to our game little Admin";
    }
}
