package PlayerInformation;

import java.io.IOException;

public class RegisterAndSignIn {

    private String username;


    public String getUserName() {
        return username;
    }

    public boolean register(String username,String pass1,String pass2) throws IOException {
   

        if (!ReaderAndWriterFileProcess.isUserAvailable(username)) {
            System.out.println("Bu kullanıcı exist.");
            return false;
        }

        if (!pass1.equals(pass2)) {
            System.out.println("notequals");
            return false;
        }

        ReaderAndWriterFileProcess.writeUser(username, pass1);
        this.username = username;
        System.out.println("Register başarılı.");
        
        
        
        return true;
    }

    public int signIn(String username,String password) throws IOException {
        System.out.print("Username: ");
       // String username = input.next();
        
        
        System.out.print("Password: ");
        //String password = input.next();
        if(username.equals("Admin")   && password.equals("admin")){
            //System.out.println("buraya gşriior eğer ");
        this.username=username;
        return 0;
        }
        if (ReaderAndWriterFileProcess.checkUserInformation(username, password)) {
            this.username = username;
            return 1;
        }

        //System.out.println("Giriş başarısız.");
        return -1;
    }
}
