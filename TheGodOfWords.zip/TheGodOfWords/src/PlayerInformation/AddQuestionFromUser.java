/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PlayerInformation;

import java.io.FileWriter;
import java.util.Scanner;

/**
 *
 * @author aliemre
 */
public class AddQuestionFromUser {
    final static private String FILE = "UsersWordsAndQuestions.txt";
    
    
    
    public static void addQuestion(String question,String answer,int Id){
 
        try (FileWriter fw=new FileWriter(FILE,true)){
            
            fw.write(answer+"###"+question+"###"+Id+"\n");
            
            
        } catch (Exception e) {
            
            e.printStackTrace();
        }
        
    
    
    
        
        
    
    
    }
    
    
    
}
