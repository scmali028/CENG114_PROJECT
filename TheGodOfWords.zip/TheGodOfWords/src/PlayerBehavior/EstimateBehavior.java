/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package PlayerBehavior;

/**
 *
 * @author alise
 */
public interface EstimateBehavior {

    public boolean estimate(String answer, String estimate, char[] currentArr);
}
