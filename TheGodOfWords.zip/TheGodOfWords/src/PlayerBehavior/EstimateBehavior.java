
package PlayerBehavior;

public interface EstimateBehavior {

    public boolean estimate(String answer, String estimate, char[] currentArr);
}
