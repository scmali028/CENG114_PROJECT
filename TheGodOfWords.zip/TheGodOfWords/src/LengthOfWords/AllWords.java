
package LengthOfWords;


public interface AllWords {

    String getQuestion();

    String getRandomWord();
}
