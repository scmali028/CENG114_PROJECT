
package PlayerBehavior;

public interface TakeLetterBehavior {

    public void takeLetter(char[]currentArr,String answer);
}
