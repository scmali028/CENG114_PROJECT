package main;

import GUI.MainMenuFrame;
import java.io.IOException;

public class TheGodOfWords {

    public static void main(String[] args) throws IOException {
        MainMenuFrame frame = new MainMenuFrame();
        frame.setVisible(true);
    }

}