/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package userBehaviors;

/**
 *
 * @author aliemre
 */
public interface EstimateQuestionBehaviors {
    public boolean estimate(String answer,String estimate,char[]current);
}
