/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */



package GUI;

import LengthOfWords.AllWords;
import LengthOfWords.EightLettersWords;
import LengthOfWords.FiveLettersWords;
import LengthOfWords.FourLettersWords;
import LengthOfWords.NineLettersWords;
import LengthOfWords.SevenLettersWords;
import LengthOfWords.SixLettersWords;
import LengthOfWords.TenLettersWords;
import java.util.ArrayList;
import java.util.List;
import Game.*;
import PlayerInformation.Submit;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

/**
 *
 * @author alise
 */
public class GameFrame extends javax.swing.JFrame {

    /**
     * Creates new form GameFrame
     */
    private int questionIndex = 0;
    private List<AllWords> LengthOfWords=new ArrayList<>();
    private static Player player;
 int howManyGotLetter = 0;
    
    public GameFrame(Player player) throws IOException {
        
        initComponents();
       // jTextFieldAnswerField.setVisible(false);
        this.player=player;
        loadCategories();
        loadQuestionAndAnswer();
        
        
        
    }
    
     public void loadCategories() {
        LengthOfWords.add(new FourLettersWords());
        LengthOfWords.add(new FiveLettersWords());
        LengthOfWords.add(new SixLettersWords());
        LengthOfWords.add(new SevenLettersWords());
        LengthOfWords.add(new EightLettersWords());
        LengthOfWords.add(new NineLettersWords());
        LengthOfWords.add(new TenLettersWords());
    }
     public void loadQuestionAndAnswer() throws IOException{
     if(questionIndex<LengthOfWords.size()-5)    {
         howManyGotLetter=0;
         
     String randomWord=LengthOfWords.get(questionIndex).getRandomWord().toLowerCase();
     String question=LengthOfWords.get(questionIndex).getQuestion();
     jTextAreaQuestion.setText(question);
     
     player.getEngine().setNewWord(randomWord);
     String output="\n\n                "+player.getEngine().getPrintNoVisibleState();
     jTextAreaHiddenAnswer.setText(output);
     
     
     
     }else{
     double finalScore = player.getEngine().getScore();

    JOptionPane.showMessageDialog(
        this,
        player.toString()
    );
   
         try { Submit sb = new Submit(player);
              sb.writeOnScoreboard();
              sb.writeOnLeaderboard();
         } catch (Exception e) {
             e.toString();
                     
         }
       

    SkorFrame skorFrame = new SkorFrame(player);
    skorFrame.setVisible(true);

    this.dispose(); // GameFrame kapanır
     }
     
     }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButtonPass = new javax.swing.JButton();
        jButtonTakeLetter = new javax.swing.JButton();
        jButtonEstimate = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextAreaHiddenAnswer = new javax.swing.JTextArea();
        jLabelScore = new javax.swing.JLabel();
        jLabelReachablePoint = new javax.swing.JLabel();
        jLabelLifeOrTime = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextAreaQuestion = new javax.swing.JTextArea();
        jButtonExit = new javax.swing.JButton();
        jTextFieldAnswerField = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButtonPass.setText("Pass");
        jButtonPass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPassActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonPass, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 210, 108, 33));

        jButtonTakeLetter.setText("Take Letter");
        jButtonTakeLetter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonTakeLetterActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonTakeLetter, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 210, 108, 35));

        jButtonEstimate.setText("Estimate");
        jButtonEstimate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEstimateActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonEstimate, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, 108, 35));

        jTextAreaHiddenAnswer.setColumns(20);
        jTextAreaHiddenAnswer.setFont(new java.awt.Font("Helvetica Neue", 1, 18)); // NOI18N
        jTextAreaHiddenAnswer.setRows(5);
        jTextAreaHiddenAnswer.setText("\n\n------------------ ");
        jScrollPane1.setViewportView(jTextAreaHiddenAnswer);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 90, 110, 40));

        jLabelScore.setText("Score :");
        jPanel1.add(jLabelScore, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 140, -1));

        jLabelReachablePoint.setText("reachable point");
        jPanel1.add(jLabelReachablePoint, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 150, -1));

        jLabelLifeOrTime.setText("can/süre");
        jPanel1.add(jLabelLifeOrTime, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 120, -1));

        jTextAreaQuestion.setColumns(20);
        jTextAreaQuestion.setRows(5);
        jTextAreaQuestion.setText("SORUSU geşcek buraya");
        jScrollPane2.setViewportView(jTextAreaQuestion);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 160, 240, 40));

        jButtonExit.setText("exit");
        jButtonExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonExitActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonExit, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 280, -1, -1));
        jPanel1.add(jTextFieldAnswerField, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 260, 90, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonPassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPassActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButtonPassActionPerformed

    private void jButtonEstimateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEstimateActionPerformed
    jTextFieldAnswerField.setVisible(true);
    
    String guess = jTextFieldAnswerField.getText(); // (bunu eklemen lazım)

    boolean correct = player.getEngine().performEstimate(guess);

    if (correct) {
        player.getEngine().addScore(howManyGotLetter);
        questionIndex++;
        try {
            loadQuestionAndAnswer();
        } catch (IOException ex) {
            Logger.getLogger(GameFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    } else {
        player.getEngine().loseLife();
    }

    updateScreen();
  
    }//GEN-LAST:event_jButtonEstimateActionPerformed

    private void jButtonExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonExitActionPerformed
System.exit(0);
    }//GEN-LAST:event_jButtonExitActionPerformed

    private void jButtonTakeLetterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonTakeLetterActionPerformed
        howManyGotLetter++;
        player.getEngine().performTakingLetter();
        jLabelReachablePoint.setText("Reachable Point2: "+player.getEngine().getReachableScore(howManyGotLetter));
        if(player.getEngine().isCompleted()){
        questionIndex++;
        
            try {
                loadQuestionAndAnswer();
            } catch (IOException ex) {
                Logger.getLogger(GameFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
          updateScreen();
      
        
        // TODO add your handling code here:
    }//GEN-LAST:event_jButtonTakeLetterActionPerformed
    private void updateScreen() {
       //howManyGotLetter=0;
    jLabelLifeOrTime.setText("Life: " + player.getEngine().getLife());
    jLabelScore.setText("Score: " + player.getEngine().getScore());
    //jLabelReachablePoint.setText("Reachable Point: "+player.getEngine().getReachableScore(howManyGotLetter));
    jTextAreaHiddenAnswer.setText(
        new String(player.getEngine().getCurrent())
    );
}
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
      
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GameFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GameFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GameFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GameFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new GameFrame(player).setVisible(true);
                } catch (IOException ex) {
                    Logger.getLogger(GameFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonEstimate;
    private javax.swing.JButton jButtonExit;
    private javax.swing.JButton jButtonPass;
    private javax.swing.JButton jButtonTakeLetter;
    private javax.swing.JLabel jLabelLifeOrTime;
    private javax.swing.JLabel jLabelReachablePoint;
    private javax.swing.JLabel jLabelScore;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextAreaHiddenAnswer;
    private javax.swing.JTextArea jTextAreaQuestion;
    private javax.swing.JTextField jTextFieldAnswerField;
    // End of variables declaration//GEN-END:variables
}
